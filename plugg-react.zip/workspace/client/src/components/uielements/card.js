import { Card } from 'antd';

export default Card;
