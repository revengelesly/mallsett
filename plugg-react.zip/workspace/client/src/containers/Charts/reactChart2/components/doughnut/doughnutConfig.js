const data = {
	labels: [
		'Red',
		'Blue',
		'Yellow'
	],
	datasets: [{
		data: [300, 50, 100],
		backgroundColor: [
		'#ff6384',
		'#48A6F2',
		'#ffbf00'
		],
		hoverBackgroundColor: [
		'#FF6384',
		'#48A6F2',
		'#ffbf00'
		]
	}]
};

export {
	data,
}
