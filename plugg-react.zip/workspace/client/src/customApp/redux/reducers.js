import githubSearch from './githubSearch/reducers';

export default { githubSearch };
