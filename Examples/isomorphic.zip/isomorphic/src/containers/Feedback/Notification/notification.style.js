import styled from 'styled-components';

const NotificationContent = styled.div`
  display: inline-block;
  font-size: 13px;
`;

export default NotificationContent;
