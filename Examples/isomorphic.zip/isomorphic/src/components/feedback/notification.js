import { notification } from 'antd';

export default notification;