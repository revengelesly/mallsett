const options = [
  {
    key: "authCheck",
    label: "sidebar.authCheck",
    leftIcon: "ion-document"
  }
];
export default options;
