const options = [
  {
    key: "blankPage",
    label: "sidebar.blankPage",
    leftIcon: "ion-document"
  }
];
export default options;
