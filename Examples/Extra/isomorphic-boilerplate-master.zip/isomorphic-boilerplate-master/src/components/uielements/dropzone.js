import Dropzone from 'react-dropzone-component';
import 'dropzone/dist/min/dropzone.min.css';

export default Dropzone;
