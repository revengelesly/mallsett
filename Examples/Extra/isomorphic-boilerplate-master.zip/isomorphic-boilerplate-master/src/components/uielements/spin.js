import { Spin } from 'antd';

export default Spin;
