import { Mention } from 'antd';

export default Mention;