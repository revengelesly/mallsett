import SignUp from './SignUp/index';
import SignIn from './SignIn/';
export {
	SignUp,
	SignIn
}