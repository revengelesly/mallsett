import { Carousel } from 'antd';

export default Carousel;
