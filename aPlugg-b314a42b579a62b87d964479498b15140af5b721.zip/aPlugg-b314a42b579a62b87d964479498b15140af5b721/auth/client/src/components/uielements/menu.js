import { Menu } from 'antd';

export default Menu;