module.exports = {
  database: 'mongodb://kamran:kamran@ds133657.mlab.com:33657/aplugg',
  secret: 'yoursecret'
}
