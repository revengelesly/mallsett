import React, { Component } from 'react';
import { Row, Col } from 'antd';
import { Card, Icon, Avatar } from 'antd';

const Meta = Card;

class ItemUser extends Component {
  render() {
    return (
      <div>
        Use this to show the user information:<br />
        Make design look like this<br />
        https://ant.design/components/card/#
        
        <br /><br />
        choose the Card that is right below "with tab". should be the last one.
      </div>
    );
  }
}

export default ItemUser;