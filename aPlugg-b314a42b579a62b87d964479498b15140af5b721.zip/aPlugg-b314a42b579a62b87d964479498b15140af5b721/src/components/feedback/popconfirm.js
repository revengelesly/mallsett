import { Popconfirm } from 'antd';

export default Popconfirm;